#!/usr/bin/env bash
set -euo pipefail

BUCKET="${BUCKET:-innovateme.systems}"
DISTRIBUTION_ID="${DISTRIBUTION_ID:-}"

aws s3 sync "$(cd "$(dirname "$0")" && pwd)/" "s3://${BUCKET}/" \
  --delete \
  --exclude '.DS_Store' \
  --exclude 'README.md' \
  --exclude 'deploy.sh'

if [[ -n "${DISTRIBUTION_ID}" ]]; then
  aws cloudfront create-invalidation \
    --distribution-id "${DISTRIBUTION_ID}" \
    --paths '/*'
else
  echo "S3 upload complete. Set DISTRIBUTION_ID to invalidate CloudFront automatically."
fi
