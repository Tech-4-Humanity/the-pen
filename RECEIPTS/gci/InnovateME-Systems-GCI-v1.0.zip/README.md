# InnovateME Systems — Global Capability Initiative

Static, dependency-free submission website for `innovateme.systems`.

## What is included

- Editorial ecosystem-led homepage
- Founding Sponsor invitation for United World Leaders
- Responsive global systems visual
- 50+ routed publication pages generated from a canonical content registry
- Framework, Index, governance, research, pilots and sponsorship content
- Mobile, print and accessibility-conscious styles
- No backend, database, framework, build service or Vercel dependency

## Local dry run

From this directory:

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

## Deploy to S3

Replace the bucket name if your existing bucket differs:

```bash
aws s3 sync ./ s3://innovateme.systems/ \
  --delete \
  --exclude '.DS_Store' \
  --exclude 'README.md'
```

Set `index.html` as the S3 website index document. The site uses hash routes, so no server rewrite is required.

## CloudFront

```bash
aws cloudfront create-invalidation \
  --distribution-id YOUR_DISTRIBUTION_ID \
  --paths '/*'
```

Recommended response headers policy:

- Strict-Transport-Security
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin
- Content-Security-Policy allowing only self-hosted CSS and JavaScript

## Domain

Use Route 53 alias records for:

- `innovateme.systems`
- `www.innovateme.systems` (redirect or same distribution)

ACM certificate must be created in `us-east-1` for CloudFront.

## Content model

`assets/content.js` is the canonical page registry. Each entry contains:

- title
- publication state
- executive summary
- body
- related pages

The publication state is intentionally visible so proposed, illustrative, evidence-aware and roadmap content are not presented as completed facts.

## Current release state

This is a real deployable static website foundation and coherent digital submission. It is not a claim that legal review, independent methodology validation, sponsor acceptance or pilot commitments have occurred.
