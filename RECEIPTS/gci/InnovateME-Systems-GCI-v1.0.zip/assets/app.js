(() => {
  const page = document.getElementById('page');
  const hero = document.getElementById('hero');
  const nav = document.getElementById('nav');
  const menu = document.getElementById('menuButton');
  const pages = window.GCI_PAGES || {};

  const esc = (s='') => s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function renderRelated(keys=[]) {
    return keys.map(key => {
      const item = pages[key];
      return item ? `<a href="#/${key}">${esc(item.title)}</a>` : '';
    }).join('');
  }

  function render(slug) {
    const item = pages[slug] || pages.home;
    const isHome = slug === 'home' || !pages[slug];
    hero.hidden = !isHome;
    document.querySelector('.ask-band').hidden = !isHome;
    document.querySelector('.system-map').hidden = !isHome;
    document.querySelector('.ecosystems').hidden = !isHome;

    if (isHome) {
      page.innerHTML = '';
      document.title = 'InnovateME Systems | Global Capability Initiative';
      window.scrollTo({top:0,behavior:'smooth'});
      return;
    }

    document.title = `${item.title} | Global Capability Initiative`;
    const paragraphs = (item.body || []).map(p => `<p>${esc(p)}</p>`).join('');
    page.innerHTML = `
      <article class="page-shell">
        <div class="page-copy">
          <p class="eyebrow">Global Capability Initiative</p>
          <span class="content-state">${esc(item.state || 'Proposed')}</span>
          <h1>${esc(item.title)}</h1>
          <p class="summary">${esc(item.summary || '')}</p>
          ${paragraphs}
          <div class="metrics">
            <div class="metric"><b>People first</b><span>Capability is never a ranking of human worth.</span></div>
            <div class="metric"><b>Evidence aware</b><span>Claims show confidence, context and limitations.</span></div>
            <div class="metric"><b>Action linked</b><span>Measurement must lead to practical improvement.</span></div>
          </div>
          ${slug === 'founding-sponsor' ? `<blockquote class="quote">We invite United World Leaders to become the Founding Sponsor and International Steward of the Global Capability Initiative and the Global Capability Index.</blockquote>` : ''}
          <p><a class="button primary" href="#/contact">Discuss participation</a></p>
        </div>
        <aside class="related" aria-label="Related pages">
          <h3>Continue exploring</h3>
          ${renderRelated(item.related)}
          <a href="#/downloads">Publications</a>
          <a href="#/home">Return home</a>
        </aside>
      </article>`;
    page.focus();
    window.scrollTo({top:0,behavior:'smooth'});
  }

  function route() {
    const slug = location.hash.replace(/^#\/?/, '') || 'home';
    render(slug);
    nav.classList.remove('open');
    menu.setAttribute('aria-expanded','false');
  }

  menu.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menu.setAttribute('aria-expanded', String(open));
  });
  window.addEventListener('hashchange', route);
  route();
})();