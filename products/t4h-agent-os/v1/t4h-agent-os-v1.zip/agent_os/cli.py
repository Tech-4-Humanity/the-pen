from __future__ import annotations

import argparse
import json
import os
import shutil
import re
import shlex
import sqlite3
import subprocess
import time
import uuid
from pathlib import Path

ROOT = Path(os.environ.get("AGENT_OS_HOME", Path(__file__).parents[1])).resolve()
DB = Path(os.environ.get("AGENT_OS_DB", ROOT / "runtime" / "ledger.sqlite3"))
REGISTRY = Path(os.environ.get("AGENT_OS_REGISTRY", ROOT / "dist" / "data" / "registry.json"))
ANSI_RE = re.compile(r"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07]*(?:\x07|\x1b\\))")
REQUIRED_RESULT_FIELDS = ("status", "result", "evidence", "gaps", "next_action", "confidence")
PERSISTENCE_MANDATE = """You must complete the entire task or stride to a verified working outcome before stopping or reporting back. Treat every partial win as temporary. Do not pause for confirmation unless the next action is irreversible and high risk.
At the start of every run load and remember the full thread history all prior decisions open files and the exact workspace state. Never start cold. Use the same resources and memory every time.
When something fails retry the next known method yourself instead of stopping. Keep acting until the full outcome is done and checked.
Finish the current stride completely in one continuous pass. Do not break work into thin layers that reverse. Expand the step until the whole piece is solid."""
STATUS_ALIASES = {
    "SUCCESS": "REAL", "SUCCEEDED": "REAL", "COMPLETE": "REAL", "COMPLETED": "REAL",
    "PASS": "REAL", "PASSED": "REAL", "OK": "REAL", "TRUE": "REAL",
    "FAIL": "BLOCKED", "FAILED": "BLOCKED", "FAILURE": "BLOCKED", "ERROR": "BLOCKED",
    "IN_PROGRESS": "PARTIAL", "IN PROGRESS": "PARTIAL", "PENDING": "PARTIAL",
    "WARNING": "DEGRADED", "WARN": "DEGRADED",
}

def connect() -> sqlite3.Connection:
    DB.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("""CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, kind TEXT NOT NULL, target TEXT NOT NULL, task TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, started REAL, finished REAL, result TEXT, error TEXT)""")
    db.execute("""CREATE TABLE IF NOT EXISTS receipts(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT NOT NULL, event TEXT NOT NULL, at REAL NOT NULL, payload TEXT NOT NULL)""")
    db.commit()
    return db

def emit(db: sqlite3.Connection, job_id: str, event: str, payload: dict) -> None:
    db.execute("INSERT INTO receipts(job_id,event,at,payload) VALUES(?,?,?,?)", (job_id,event,time.time(),json.dumps(payload)))
    db.commit()

def load_registry() -> dict:
    return json.loads(REGISTRY.read_text(encoding="utf-8"))

def provider() -> str:
    if os.environ.get("AGENT_OS_TEST_PROVIDER") == "1": return "test"
    if os.environ.get("AGENT_OS_COMMAND") or os.environ.get("QWEN_AGENT_COMMAND"): return "command"
    if shutil.which("ollama") or shutil.which("qwen"): return "command"
    return "missing"

def provider_command() -> str:
    """Return the provider-neutral command, retaining V0 compatibility."""
    configured = os.environ.get("AGENT_OS_COMMAND") or os.environ.get("QWEN_AGENT_COMMAND")
    if configured:
        return configured
    if shutil.which("ollama"):
        return f"{shutil.which('ollama')} run {os.environ.get('AGENT_OS_MODEL', 'qwen2.5-coder:7b')} {{prompt}}"
    if shutil.which("qwen"):
        return f"{shutil.which('qwen')} -p {{prompt}}"
    return ""

def provider_telemetry() -> dict:
    if os.environ.get("AGENT_OS_TEST_PROVIDER") == "1":
        return {"type": "test", "model": "test-model", "executable": "internal",
                "resolved_executable": "internal"}
    command = provider_command()
    try:
        argv = shlex.split(command)
    except ValueError as exc:
        return {"type": "invalid", "model": None, "executable": None, "error": str(exc)}
    executable = argv[0] if argv else None
    base = Path(executable).name if executable else ""
    if base == "ollama":
        model = argv[2] if len(argv) > 2 and argv[1] == "run" else None
        kind = "ollama"
    elif base == "qwen":
        model = os.environ.get("AGENT_OS_MODEL") or os.environ.get("QWEN_MODEL")
        kind = "qwen-cli"
    else:
        model, kind = os.environ.get("AGENT_OS_MODEL") or os.environ.get("QWEN_MODEL"), "custom-command"
    return {"type": kind, "model": model, "executable": executable,
            "resolved_executable": shutil.which(executable) if executable else None}

def clean_output(value: str) -> str:
    return ANSI_RE.sub("", value).replace("\r", "").strip()

def validate_result(raw: str) -> dict:
    cleaned = clean_output(raw)
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", cleaned, re.DOTALL | re.IGNORECASE)
    candidate = fenced.group(1) if fenced else cleaned
    try:
        result = json.loads(candidate)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"INVALID_RESULT_JSON: {exc.msg} at position {exc.pos}") from exc
    if not isinstance(result, dict):
        raise RuntimeError("INVALID_RESULT_SCHEMA: root must be an object")
    missing = [field for field in REQUIRED_RESULT_FIELDS if field not in result]
    if missing:
        raise RuntimeError(f"INVALID_RESULT_SCHEMA: missing {','.join(missing)}")
    original_status = str(result["status"]).strip().upper()
    canonical_status = STATUS_ALIASES.get(original_status, original_status)
    if canonical_status not in {"REAL", "PARTIAL", "BLOCKED", "DEGRADED", "QUARANTINED", "ASPIRATIONAL"}:
        raise RuntimeError(f"INVALID_RESULT_SCHEMA: unsupported status {original_status!r}")
    result["status"] = canonical_status
    if canonical_status != original_status:
        result["source_status"] = original_status
    if not isinstance(result["confidence"], (int, float)) or not 0 <= result["confidence"] <= 100:
        raise RuntimeError("INVALID_RESULT_SCHEMA: confidence must be 0..100")
    return result

def execute(prompt: str) -> tuple[dict, dict]:
    p = provider()
    if p == "test":
        return ({"status":"REAL", "result":"test provider completed task", "evidence":"test provider receipt",
                 "gaps":[], "next_action":"none", "confidence":100}, provider_telemetry())
    if p == "missing": raise RuntimeError("No model provider. Install Ollama/Qwen CLI or set AGENT_OS_COMMAND.")
    command = provider_command()
    if "{prompt}" not in command: raise RuntimeError("AGENT_OS_COMMAND must contain {prompt}")
    argv = [part.replace("{prompt}", prompt) for part in shlex.split(command)]
    started = time.monotonic()
    proc = subprocess.run(argv, text=True, capture_output=True, timeout=int(os.environ.get("AGENT_OS_TIMEOUT", "600")))
    duration = round(time.monotonic() - started, 3)
    if proc.returncode: raise RuntimeError(proc.stderr[-2000:] or f"provider exited {proc.returncode}")
    telemetry = provider_telemetry() | {"duration_seconds": duration, "exit_code": proc.returncode}
    return validate_result(proc.stdout), telemetry

def enqueue(kind: str, target: str, task: str) -> str:
    reg = load_registry(); collection = "agents" if kind == "agent" else "arenas"
    valid = {x["name"] for x in reg[collection]} | {x["id"] for x in reg[collection]}
    if target not in valid: raise SystemExit(f"Unknown {kind}: {target}")
    job_id = f"JOB-{uuid.uuid4().hex[:12]}"; db = connect()
    db.execute("INSERT INTO jobs(id,kind,target,task,status,created) VALUES(?,?,?,?,?,?)", (job_id,kind,target,task,"QUEUED",time.time())); db.commit()
    emit(db, job_id, "QUEUED", {"kind":kind,"target":target})
    return job_id

def work_once() -> bool:
    db = connect(); row = db.execute("SELECT * FROM jobs WHERE status='QUEUED' ORDER BY created LIMIT 1").fetchone()
    if not row: return False
    db.execute("UPDATE jobs SET status='RUNNING',started=? WHERE id=?",(time.time(),row["id"])); db.commit(); emit(db,row["id"],"CLAIMED",{"worker":os.getpid()})
    try:
        runtime_context = json.dumps(provider_telemetry(), sort_keys=True)
        result, telemetry = execute(f"{PERSISTENCE_MANDATE}\n\nTarget: {row['target']}\nTask: {row['task']}\nVerified runtime context: {runtime_context}\nReturn ONLY valid JSON with: status, result, evidence, gaps, next_action, confidence. Canonical status must be one of REAL, PARTIAL, BLOCKED, DEGRADED, QUARANTINED, ASPIRATIONAL. No markdown fences or terminal formatting.")
        encoded = json.dumps(result, ensure_ascii=False)
        terminal = "COMPLETED" if result["status"] == "REAL" else result["status"]
        db.execute("UPDATE jobs SET status=?,finished=?,result=? WHERE id=?",(terminal,time.time(),encoded,row["id"])); db.commit()
        emit(db,row["id"],terminal,{"result_chars":len(encoded),"validation":"PASS","provider":telemetry})
    except subprocess.TimeoutExpired as exc:
        error = f"PROVIDER_TIMEOUT: exceeded {exc.timeout} seconds"
        db.execute("UPDATE jobs SET status='BLOCKED',finished=?,error=? WHERE id=?",(time.time(),error,row["id"])); db.commit(); emit(db,row["id"],"BLOCKED",{"classification":"TIMEOUT","error":error,"provider":provider_telemetry()})
    except Exception as exc:
        db.execute("UPDATE jobs SET status='BLOCKED',finished=?,error=? WHERE id=?",(time.time(),str(exc),row["id"])); db.commit(); emit(db,row["id"],"BLOCKED",{"error":str(exc)})
    return True

def show(job_id: str) -> dict:
    db=connect(); job=db.execute("SELECT * FROM jobs WHERE id=?",(job_id,)).fetchone()
    if not job: raise SystemExit("Unknown job")
    receipts=[dict(x) for x in db.execute("SELECT * FROM receipts WHERE job_id=? ORDER BY id",(job_id,))]
    return {"job":dict(job),"receipts":receipts}

def doctor() -> dict:
    counts={}; errors=[]
    try:
        reg=load_registry(); counts={k:len(reg[k]) for k in ("agents","arenas","playbooks")}
    except Exception as exc: errors.append(str(exc))
    p=provider()
    telemetry = provider_telemetry()
    if p != "missing" and not telemetry.get("resolved_executable") and p != "test": errors.append("provider executable unavailable")
    return {"status":"REAL" if not errors and p != "missing" else "DEGRADED", "registry":counts, "ledger":str(DB), "provider":telemetry, "timeout_seconds":int(os.environ.get("AGENT_OS_TIMEOUT", "600")), "strict_output":True, "errors":errors + (["model provider unavailable"] if p=="missing" else [])}

def main() -> None:
    ap=argparse.ArgumentParser(prog="agent-os"); sub=ap.add_subparsers(dest="cmd",required=True)
    for command,kind in (("invoke","agent"),("arena","arena")):
        p=sub.add_parser(command); p.add_argument("target"); p.add_argument("--task",required=True); p.set_defaults(kind=kind)
    p=sub.add_parser("status"); p.add_argument("job_id")
    p=sub.add_parser("finish"); p.add_argument("job_id")
    p=sub.add_parser("worker"); p.add_argument("--once",action="store_true"); p.add_argument("--poll",type=float,default=2)
    sub.add_parser("doctor")
    args=ap.parse_args()
    if args.cmd in {"invoke","arena"}: print(json.dumps({"job_id":enqueue(args.kind,args.target,args.task),"status":"QUEUED"}))
    elif args.cmd in {"status","finish"}: print(json.dumps(show(args.job_id),indent=2))
    elif args.cmd=="doctor": print(json.dumps(doctor(),indent=2))
    else:
        if args.once: work_once(); return
        while True:
            work_once(); time.sleep(args.poll)

if __name__ == "__main__": main()
