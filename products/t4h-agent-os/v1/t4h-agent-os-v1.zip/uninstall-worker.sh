#!/usr/bin/env bash
set -Eeuo pipefail
if command -v systemctl >/dev/null 2>&1; then
  systemctl --user disable --now t4h-agent-os.service 2>/dev/null || true
fi
if command -v launchctl >/dev/null 2>&1; then
  launchctl bootout "gui/$(id -u)/au.com.tech4humanity.t4h-agent-os" 2>/dev/null || true
fi
echo "Worker stopped. Runtime data and agent definitions were preserved."
