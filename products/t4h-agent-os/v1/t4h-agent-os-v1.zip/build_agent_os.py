#!/usr/bin/env python3
"""Build T4H Agent OS from a single canonical registry."""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path

AGENT_NAMES = [
    "orchestrator", "researcher", "architect", "repository-intelligence",
    "builder", "debugger", "github", "vercel", "deployment", "release-manager",
    "frontend", "backend", "python", "ai-systems", "mcp-specialist", "tester",
    "browser-verifier", "reviewer", "security", "dependency-security", "performance",
    "data-engineer", "data-analyst", "market-intelligence", "knowledge-analyst",
    "evidence-auditor", "financial-reconciler", "rdti-analyst", "documenter",
    "technical-writer", "fact-checker", "qa-auditor", "change-auditor", "cost-optimizer",
    "sre", "api-designer", "compliance", "product", "system-librarian",
]

READ_ONLY = {"researcher", "architect", "repository-intelligence", "reviewer", "security",
             "dependency-security", "performance", "data-analyst", "market-intelligence",
             "knowledge-analyst", "evidence-auditor", "financial-reconciler", "rdti-analyst",
             "technical-writer", "fact-checker", "qa-auditor", "change-auditor", "cost-optimizer",
             "compliance", "product", "system-librarian", "deployment", "release-manager",
             "browser-verifier", "sre", "api-designer"}

ARENAS = [
    ("T1", "architecture", "technical"), ("T2", "code-implementation", "technical"),
    ("T3", "debugging", "technical"), ("T4", "security", "technical"),
    ("T5", "dependency-cve", "technical"), ("T6", "frontend-ui", "technical"),
    ("T7", "test-strategy", "technical"), ("T8", "performance", "technical"),
    ("T9", "deployment-infrastructure", "technical"), ("T10", "ai-agent-architecture", "technical"),
    ("T11", "prompt", "technical"), ("T12", "schema", "technical"),
    ("N1", "research", "non-technical"), ("N2", "strategic-analysis", "non-technical"),
    ("N3", "critical-thinking", "non-technical"), ("N4", "evidence-fact-checking", "non-technical"),
    ("N5", "policy", "non-technical"), ("N6", "economics", "non-technical"),
    ("N7", "writing", "non-technical"), ("N8", "editorial", "non-technical"),
    ("N9", "communication", "non-technical"), ("N10", "decision", "non-technical"),
    ("M1", "devils-advocate", "meta"), ("M2", "red-team", "meta"),
    ("M3", "independent-expert", "meta"), ("M4", "jury", "meta"),
]

PLAYBOOKS = {
    "incident-response": ["sre", "debugger", "security", "tester", "deployment"],
    "new-feature": ["product", "architect", "builder", "tester", "reviewer", "qa-auditor"],
    "dependency-cve": ["dependency-security", "security", "builder", "tester", "reviewer"],
    "rdti-submission": ["rdti-analyst", "financial-reconciler", "evidence-auditor", "fact-checker"],
    "release": ["release-manager", "tester", "security", "deployment", "qa-auditor"],
    "research-to-decision": ["researcher", "knowledge-analyst", "fact-checker", "orchestrator"],
}

ROLE_OVERRIDES = {
    "orchestrator": "Route work, control dependencies, and synthesize evidence-backed outcomes.",
    "builder": "Implement scoped changes with tests and leave verifiable receipts.",
    "python": "Build typed, tested Python applications, automation, and data tooling.",
    "sre": "Own production reliability, SLOs, incidents, observability, and recovery.",
    "system-librarian": "Govern the agent registry, lifecycle, duplication, and prompt drift.",
}

PERSISTENCE_MANDATE = """You must complete the entire task or stride to a verified working outcome before stopping or reporting back. Treat every partial win as temporary. Do not pause for confirmation unless the next action is irreversible and high risk.
At the start of every run load and remember the full thread history all prior decisions open files and the exact workspace state. Never start cold. Use the same resources and memory every time.
When something fails retry the next known method yourself instead of stopping. Keep acting until the full outcome is done and checked.
Finish the current stride completely in one continuous pass. Do not break work into thin layers that reverse. Expand the step until the whole piece is solid."""

def agent_record(index: int, name: str) -> dict:
    writable = name not in READ_ONLY
    return {
        "id": f"{index:02d}", "name": name,
        "role": ROLE_OVERRIDES.get(name, f"Own {name.replace('-', ' ')} work within a narrow specialist boundary."),
        "model_profile": "reasoning" if name in {"orchestrator", "architect", "ai-systems", "security", "data-analyst", "market-intelligence", "knowledge-analyst", "evidence-auditor", "financial-reconciler", "rdti-analyst", "technical-writer", "fact-checker", "compliance", "product"} else "coding",
        "approval_mode": "auto" if not writable else "confirm",
        "tools": {"read": True, "edit": writable, "shell": writable, "github": name in {"github", "builder", "debugger", "tester", "documenter"}, "deploy": False},
        "triggers": [name, name.replace("-", " ")],
        "memory": "Task-local evidence plus receipt references; mutable facts must be refreshed.",
        "context": "Receive intent, constraints, relevant files, dependencies, and explicit success criteria.",
        "outputs": ["result", "evidence", "gaps", "next_action", "confidence"],
    }

def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")

def prompt_for(a: dict) -> str:
    allowed = [k for k, v in a["tools"].items() if v]
    denied = [k for k, v in a["tools"].items() if not v]
    return f'''---
name: {a['name']}
description: {a['role']}
modelProfile: {a['model_profile']}
approvalMode: {a['approval_mode']}
tools:
  allowed: [{', '.join(allowed)}]
  disallowed: [{', '.join(denied)}]
---

# System Prompt

{PERSISTENCE_MANDATE}

You are the {a['name'].replace('-', ' ').title()} specialist.

## Mission
{a['role']}

## Operating contract
1. Stay inside the delegated scope; return strategy conflicts to the orchestrator.
2. Validate inputs and mutable facts before acting.
3. Never expose secrets. Never claim an action without a receipt.
4. Record dependencies, blockers, evidence, and recovery instructions.
5. Finish with: status, result, evidence, gaps, next_action, confidence.

## Completion gate
Work is complete only when the requested outcome is verified. Classify it REAL,
PARTIAL, BLOCKED, DEGRADED, QUARANTINED, or ASPIRATIONAL. No receipt means not REAL.
'''

def page(title: str, body: str, root: str = "../../") -> str:
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title><link rel="stylesheet" href="{root}css/styles.css"></head><body><header><a href="{root}index.html">T4H Agent OS</a><nav><a href="{root}index.html#agents">Agents</a><a href="{root}index.html#arenas">Arenas</a><a href="{root}index.html#playbooks">Playbooks</a><a href="{root}index.html#runtime">Runtime</a></nav></header><main>{body}</main></body></html>'''

def build(out: Path) -> dict:
    agents = [agent_record(i, n) for i, n in enumerate(AGENT_NAMES)]
    arenas = [{"id": i, "name": n, "category": c, "models": 3,
               "criteria": [{"name": "correctness", "weight": 35}, {"name": "evidence", "weight": 25}, {"name": "risk", "weight": 20}, {"name": "actionability", "weight": 20}]}
              for i, n, c in ARENAS]
    playbooks = [{"id": f"P{i+1}", "name": n, "steps": s} for i, (n, s) in enumerate(PLAYBOOKS.items())]
    registry = {"schema": "t4h.agent-os.v1", "product": "T4H Agent OS", "version": "1.0.0", "agents": agents, "arenas": arenas, "playbooks": playbooks}
    write(out / "data/registry.json", json.dumps(registry, indent=2))
    for a in agents:
        slug = f"{a['id']}-{a['name']}"
        write(out / f"agents/{slug}.md", prompt_for(a))
        tools = "".join(f"<tr><td>{html.escape(k)}</td><td>{'allowed' if v else 'denied'}</td></tr>" for k,v in a["tools"].items())
        body = f"<h1>{a['id']} · {html.escape(a['name'])}</h1><p class=lead>{html.escape(a['role'])}</p><section><h2>Human brief</h2><p>Use for {html.escape(', '.join(a['triggers']))}. Do not use it to redesign work outside this specialty.</p></section><section><h2>Machine contract</h2><pre>{html.escape(json.dumps(a, indent=2))}</pre></section><section><h2>Tools and authority</h2><table><tr><th>Capability</th><th>Policy</th></tr>{tools}</table></section><section><h2>Memory and context</h2><p>{html.escape(a['memory'])}</p><p>{html.escape(a['context'])}</p></section><section><h2>Completion</h2><p>Must return status, result, evidence, gaps, next action, and confidence. A claim without a receipt is not REAL.</p></section>"
        write(out / f"site/pages/agents/{slug}.html", page(a["name"], body))
    for a in arenas:
        slug = f"{a['id']}-{a['name']}"
        criteria = "".join(f"<li>{c['name']}: {c['weight']}%</li>" for c in a["criteria"])
        body = f"<h1>{a['id']} · {a['name']}</h1><p class=lead>Independent comparison arena ({a['category']}).</p><section><h2>Invocation</h2><code>python -m agent_os.cli arena {a['id']} --task \"...\"</code></section><section><h2>Evaluation</h2><ul>{criteria}</ul><p>All competitors receive identical task context. Scores, rationale, evidence, and dissent are retained.</p></section>"
        write(out / f"site/pages/arenas/{slug}.html", page(a["name"], body))
        write(out / f"arenas/{slug}.md", f"---\nname: {a['name']}-arena\ntype: arena\nmodelProfiles: [reasoning, coding, independent-review]\nmax-agents: 3\n---\n\n{PERSISTENCE_MANDATE}\n\n# {a['name'].title()} Arena\n\nRun competitors independently. Preserve all outputs and score correctness 35%, evidence 25%, risk 20%, actionability 20%.\n")
    for p in playbooks:
        flow = " → ".join(p["steps"])
        body = f"<h1>{p['name'].replace('-', ' ').title()}</h1><p class=lead>{flow}</p><section><h2>Machine sequence</h2><pre>{html.escape(json.dumps(p, indent=2))}</pre></section><section><h2>Gates</h2><p>Each step must produce a receipt. Stop on missing authority, safety/legal concerns, destructive action, credential gaps, or disputed truth.</p></section>"
        write(out / f"site/pages/playbooks/{p['id']}-{p['name']}.html", page(p["name"], body))
        write(out / f"playbooks/{p['name']}.md", f"{PERSISTENCE_MANDATE}\n\n# {p['name'].replace('-', ' ').title()}\n\n{' -> '.join(p['steps'])}\n\nEvery stage emits a receipt and verified readback before handoff.\n")
    cards = lambda items, kind: "".join(f'<a class="card" href="pages/{kind}/{x["id"]}-{x["name"]}.html"><b>{x["id"]}</b><span>{html.escape(x["name"])}</span></a>' for x in items)
    agent_cards = "".join(f'<a class="card" href="pages/agents/{a["id"]}-{a["name"]}.html"><b>{a["id"]}</b><span>{a["name"]}</span><small>{html.escape(a["role"])}</small></a>' for a in agents)
    index = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>T4H Agent OS</title><link rel="stylesheet" href="css/styles.css"></head><body><header><b>T4H Agent OS</b><nav><a href="#agents">Agents</a><a href="#arenas">Arenas</a><a href="#playbooks">Playbooks</a><a href="#runtime">Runtime</a></nav></header><main><h1>Agents that can be called, observed, and finished.</h1><p class=lead>39 specialists, 26 evaluation arenas, 6 governed playbooks, one receipt ledger.</p><section id="runtime"><h2>Runtime contract</h2><pre>agent-os doctor\nagent-os invoke builder --task "..."\nagent-os status JOB_ID\nagent-os worker --once\nagent-os finish JOB_ID</pre></section><section id="agents"><h2>Agents</h2><div class=grid>{agent_cards}</div></section><section id="arenas"><h2>Arenas</h2><div class=grid>{cards(arenas, 'arenas')}</div></section><section id="playbooks"><h2>Playbooks</h2><div class=grid>{cards(playbooks, 'playbooks')}</div></section></main></body></html>'''
    write(out / "site/index.html", index)
    write(out / "site/css/styles.css", """:root{color-scheme:dark;--bg:#07111f;--panel:#101e30;--text:#e9f1fa;--muted:#9eb0c4;--accent:#59d8c1}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:16px system-ui,sans-serif}header{position:sticky;top:0;display:flex;justify-content:space-between;padding:1rem 5vw;background:#091728eF;border-bottom:1px solid #234}nav a,header a{color:var(--text);margin-left:1rem;text-decoration:none}main{max-width:1200px;margin:auto;padding:4rem 2rem}h1{font-size:clamp(2.2rem,6vw,5rem);max-width:900px}.lead{font-size:1.25rem;color:var(--muted);line-height:1.6}section{margin:4rem 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:1rem}.card{display:flex;flex-direction:column;gap:.5rem;background:var(--panel);border:1px solid #29405a;border-radius:12px;padding:1.1rem;color:var(--text);text-decoration:none}.card:hover{border-color:var(--accent);transform:translateY(-2px)}.card b{color:var(--accent)}.card small{color:var(--muted)}pre,code{background:#050b13;border:1px solid #29405a;border-radius:8px;padding:1rem;overflow:auto}table{border-collapse:collapse;width:100%}th,td{text-align:left;border-bottom:1px solid #29405a;padding:.7rem}a{color:var(--accent)}""")
    return {"agents": len(agents), "arenas": len(arenas), "playbooks": len(playbooks)}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "dist")
    args = parser.parse_args()
    print(json.dumps(build(args.out.resolve()), indent=2))

if __name__ == "__main__":
    main()
