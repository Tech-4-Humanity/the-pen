#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

root=Path(__file__).parent; dist=root/"dist"; data=json.loads((dist/"data/registry.json").read_text())
errors=[]
expected={"agents":39,"arenas":26,"playbooks":6}
for key,count in expected.items():
    if len(data[key])!=count: errors.append(f"{key}: expected {count}, got {len(data[key])}")
for agent in data["agents"]:
    slug=f'{agent["id"]}-{agent["name"]}'
    for path in (dist/f"agents/{slug}.md",dist/f"site/pages/agents/{slug}.html"):
        if not path.is_file(): errors.append(f"missing {path}")
for arena in data["arenas"]:
    slug=f'{arena["id"]}-{arena["name"]}'
    if sum(c["weight"] for c in arena["criteria"])!=100: errors.append(f"weights != 100: {slug}")
    for path in (dist/f"arenas/{slug}.md",dist/f"site/pages/arenas/{slug}.html"):
        if not path.is_file(): errors.append(f"missing {path}")
for playbook in data["playbooks"]:
    for agent in playbook["steps"]:
        if agent not in {a["name"] for a in data["agents"]}: errors.append(f"unknown playbook agent {agent}")
    if not (dist/f'playbooks/{playbook["name"]}.md').is_file(): errors.append(f'missing playbook {playbook["name"]}')
print(json.dumps({"status":"REAL" if not errors else "BLOCKED","checks":{"agents":39,"arenas":26,"playbooks":6,"criteria_total":100},"errors":errors},indent=2))
raise SystemExit(bool(errors))
