#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python3}"
INSTALL_TARGET="${AGENT_OS_CATALOG_DIR:-$HOME/.t4h-agent-os/catalog}"
RUNTIME_DIR="${AGENT_OS_RUNTIME_DIR:-$HOME/.local/share/t4h-agent-os}"
BIN_DIR="${AGENT_OS_BIN_DIR:-$HOME/.local/bin}"

cd "$PROJECT_DIR"
"$PYTHON_BIN" build_agent_os.py
"$PYTHON_BIN" build_dossier.py
"$PYTHON_BIN" validate.py
"$PYTHON_BIN" -m unittest discover -s tests -v
"$PYTHON_BIN" install.py --target "$INSTALL_TARGET" --force --backup

mkdir -p "$RUNTIME_DIR" "$BIN_DIR"
cp -R agent_os dist "$RUNTIME_DIR/"
cp pyproject.toml "$RUNTIME_DIR/"

cat > "$BIN_DIR/agent-os" <<EOF
#!/usr/bin/env bash
set -a
source "$RUNTIME_DIR/agent-os.env"
set +a
cd "$RUNTIME_DIR" || exit 1
exec "$PYTHON_BIN" -m agent_os.cli "\$@"
EOF
chmod 0755 "$BIN_DIR/agent-os"

if command -v qwen >/dev/null 2>&1; then
  PROVIDER_BIN="$(command -v qwen)"
  PROVIDER_COMMAND="$PROVIDER_BIN -p {prompt}"
elif command -v ollama >/dev/null 2>&1; then
  PROVIDER_BIN="$(command -v ollama)"
  MODEL="${OLLAMA_MODEL:-qwen2.5-coder:7b}"
  PROVIDER_COMMAND="$PROVIDER_BIN run $MODEL {prompt}"
else
  echo "STATUS=BLOCKED"
  echo "REASON=no_model_provider"
  echo "NEXT=set AGENT_OS_COMMAND in $RUNTIME_DIR/agent-os.env"
  exit 20
fi

cat > "$RUNTIME_DIR/agent-os.env" <<EOF
AGENT_OS_HOME=$RUNTIME_DIR
AGENT_OS_DB=$RUNTIME_DIR/ledger.sqlite3
AGENT_OS_REGISTRY=$RUNTIME_DIR/dist/data/registry.json
AGENT_OS_COMMAND='$PROVIDER_COMMAND'
AGENT_OS_TIMEOUT='600'
EOF
chmod 0600 "$RUNTIME_DIR/agent-os.env"

SERVICE_MODE="foreground"
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" = "systemd" ]; then
  UNIT_DIR="$HOME/.config/systemd/user"
  mkdir -p "$UNIT_DIR"
  cat > "$UNIT_DIR/t4h-agent-os.service" <<EOF
[Unit]
Description=T4H Agent OS Worker
After=network-online.target

[Service]
Type=simple
WorkingDirectory=$RUNTIME_DIR
EnvironmentFile=$RUNTIME_DIR/agent-os.env
ExecStart=$PYTHON_BIN -m agent_os.cli worker
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload
  systemctl --user enable --now t4h-agent-os.service
  systemctl --user is-active --quiet t4h-agent-os.service
  SERVICE_MODE="systemd-user"
elif command -v launchctl >/dev/null 2>&1; then
  PLIST="$HOME/Library/LaunchAgents/au.com.tech4humanity.t4h-agent-os.plist"
  mkdir -p "$(dirname "$PLIST")"
  cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>au.com.tech4humanity.t4h-agent-os</string>
<key>ProgramArguments</key><array><string>$PYTHON_BIN</string><string>-m</string><string>agent_os.cli</string><string>worker</string></array>
<key>WorkingDirectory</key><string>$RUNTIME_DIR</string>
<key>EnvironmentVariables</key><dict><key>AGENT_OS_HOME</key><string>$RUNTIME_DIR</string><key>AGENT_OS_DB</key><string>$RUNTIME_DIR/ledger.sqlite3</string><key>AGENT_OS_REGISTRY</key><string>$RUNTIME_DIR/dist/data/registry.json</string><key>AGENT_OS_COMMAND</key><string>$PROVIDER_COMMAND</string><key>AGENT_OS_TIMEOUT</key><string>600</string></dict>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
<key>StandardOutPath</key><string>$RUNTIME_DIR/worker.log</string>
<key>StandardErrorPath</key><string>$RUNTIME_DIR/worker.error.log</string>
</dict></plist>
EOF
  launchctl bootout "gui/$(id -u)/au.com.tech4humanity.t4h-agent-os" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$PLIST"
  SERVICE_MODE="launchd"
else
  set -a; source "$RUNTIME_DIR/agent-os.env"; set +a
  nohup "$PYTHON_BIN" -m agent_os.cli worker >"$RUNTIME_DIR/worker.log" 2>"$RUNTIME_DIR/worker.error.log" &
  echo "$!" > "$RUNTIME_DIR/worker.pid"
fi

set -a; source "$RUNTIME_DIR/agent-os.env"; set +a
DOCTOR_JSON="$($PYTHON_BIN -m agent_os.cli doctor)"
JOB_JSON="$($PYTHON_BIN -m agent_os.cli invoke python --task 'Runtime canary: return status REAL and identify the active model provider. Make no external changes.')"
JOB_ID="$($PYTHON_BIN -c 'import json,sys; print(json.load(sys.stdin)["job_id"])' <<<"$JOB_JSON")"

for _ in $(seq 1 630); do
  STATUS="$($PYTHON_BIN -m agent_os.cli status "$JOB_ID" | "$PYTHON_BIN" -c 'import json,sys; print(json.load(sys.stdin)["job"]["status"])')"
  case "$STATUS" in
    COMPLETED|BLOCKED) break ;;
  esac
  sleep 1
done

FINAL_JSON="$($PYTHON_BIN -m agent_os.cli finish "$JOB_ID")"
FINAL_STATUS="$($PYTHON_BIN -c 'import json,sys; print(json.load(sys.stdin)["job"]["status"])' <<<"$FINAL_JSON")"
RECEIPT_COUNT="$($PYTHON_BIN -c 'import json,sys; print(len(json.load(sys.stdin)["receipts"]))' <<<"$FINAL_JSON")"

echo "STATUS=$([ "$FINAL_STATUS" = COMPLETED ] && echo REAL || echo BLOCKED)"
echo "SERVICE_MODE=$SERVICE_MODE"
echo "JOB_ID=$JOB_ID"
echo "JOB_STATUS=$FINAL_STATUS"
echo "RECEIPTS=$RECEIPT_COUNT"
echo "DOCTOR=$DOCTOR_JSON"
echo "READBACK=$FINAL_JSON"
test "$FINAL_STATUS" = COMPLETED
