#!/usr/bin/env python3
"""Install the provider-neutral T4H Agent OS catalogue."""
from __future__ import annotations
import argparse
import shutil
from datetime import datetime, timezone
from pathlib import Path

def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("--target", type=Path, default=Path.home()/".t4h-agent-os"/"catalog")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--backup", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args=ap.parse_args(); root=Path(__file__).parent/"dist"
    copied=skipped=backed_up=0
    backup_root = args.target / "backups" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    for source_name,target_name in (("agents","agents"),("arenas","arenas"),("playbooks","playbooks")):
        for src in sorted((root/source_name).glob("*.md")):
            dst=args.target/target_name/src.name
            if dst.exists() and not args.force:
                skipped+=1; continue
            if not args.dry_run:
                if dst.exists() and args.backup:
                    backup = backup_root / target_name / dst.name
                    backup.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst, backup)
                    backed_up += 1
                dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
            copied+=1
    print(f"target={args.target} copied={copied} skipped={skipped} backed_up={backed_up} dry_run={args.dry_run}")

if __name__=="__main__": main()
