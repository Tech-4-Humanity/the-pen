import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).parents[1]

def run(*args, env=None):
    merged = os.environ.copy()
    merged.update(env or {})
    return subprocess.run([sys.executable, "-m", "agent_os.cli", *args], cwd=ROOT,
                          text=True, capture_output=True, env=merged, check=True)

class AgentOSAcceptance(unittest.TestCase):
    def test_persistence_mandate_heads_every_definition(self):
        sentence = "You must complete the entire task or stride to a verified working outcome"
        definitions = list((ROOT / "dist/agents").glob("*.md")) + list((ROOT / "dist/arenas").glob("*.md")) + list((ROOT / "dist/playbooks").glob("*.md"))
        self.assertEqual(len(definitions), 71)
        for path in definitions:
            self.assertIn(sentence, path.read_text(), str(path))

    def test_ansi_is_removed_and_fenced_json_is_validated(self):
        from agent_os.cli import validate_result
        raw = '\x1b[7D```json\n{"status":"REAL","result":"ok","evidence":"receipt","gaps":[],"next_action":"none","confidence":99}\n```\x1b[K'
        self.assertEqual(validate_result(raw)["result"], "ok")

    def test_malformed_and_incomplete_outputs_are_rejected(self):
        from agent_os.cli import validate_result
        with self.assertRaisesRegex(RuntimeError, "INVALID_RESULT_JSON"):
            validate_result("looks good")
        with self.assertRaisesRegex(RuntimeError, "missing"):
            validate_result('{"status":"REAL"}')

    def test_common_status_is_normalized_and_preserved(self):
        from agent_os.cli import validate_result
        value = validate_result('{"status":"SUCCESS","result":"ok","evidence":"receipt","gaps":[],"next_action":"none","confidence":95}')
        self.assertEqual(value["status"], "REAL")
        self.assertEqual(value["source_status"], "SUCCESS")

    def test_provider_model_telemetry(self):
        from unittest.mock import patch
        from agent_os.cli import provider_telemetry
        with patch.dict(os.environ, {"AGENT_OS_COMMAND":"/usr/local/bin/ollama run qwen2.5-coder:7b {prompt}"}):
            value = provider_telemetry()
        self.assertEqual(value["type"], "ollama")
        self.assertEqual(value["model"], "qwen2.5-coder:7b")

    def test_registry_is_provider_neutral(self):
        data = json.loads((ROOT / "dist/data/registry.json").read_text())
        self.assertEqual(data["schema"], "t4h.agent-os.v1")
        self.assertTrue(all("model_profile" in agent and "model" not in agent for agent in data["agents"]))

    def test_registry_counts_and_generated_surfaces(self):
        data = json.loads((ROOT / "dist/data/registry.json").read_text())
        self.assertEqual((len(data["agents"]), len(data["arenas"]), len(data["playbooks"])), (39, 26, 6))
        self.assertEqual(len(list((ROOT / "dist/agents").glob("*.md"))), 39)
        self.assertEqual(len(list((ROOT / "dist/site/pages/agents").glob("*.html"))), 39)
        self.assertEqual(len(list((ROOT / "dist/site/pages/arenas").glob("*.html"))), 26)
        self.assertEqual(len(list((ROOT / "dist/site/pages/playbooks").glob("*.html"))), 6)

    def test_agent_lifecycle_has_receipts(self):
        with tempfile.TemporaryDirectory() as temp:
            env = {"AGENT_OS_DB": str(Path(temp) / "ledger.sqlite3"), "AGENT_OS_TEST_PROVIDER": "1"}
            created = json.loads(run("invoke", "python", "--task", "smoke test", env=env).stdout)
            run("worker", "--once", env=env)
            state = json.loads(run("finish", created["job_id"], env=env).stdout)
            self.assertEqual(state["job"]["status"], "COMPLETED")
            self.assertEqual([r["event"] for r in state["receipts"]], ["QUEUED", "CLAIMED", "COMPLETED"])

    def test_unknown_agent_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            result = subprocess.run([sys.executable, "-m", "agent_os.cli", "invoke", "not-real", "--task", "x"],
                                    cwd=ROOT, text=True, capture_output=True,
                                    env={**os.environ, "AGENT_OS_DB": str(Path(temp) / "ledger.sqlite3")})
            self.assertNotEqual(result.returncode, 0)

if __name__ == "__main__":
    unittest.main()
