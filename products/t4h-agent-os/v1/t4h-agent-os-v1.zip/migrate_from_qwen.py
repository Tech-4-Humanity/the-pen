#!/usr/bin/env python3
"""Back up and remove only the 71 legacy managed definitions from ~/.qwen."""
from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true", help="perform the backup and removal")
    parser.add_argument("--legacy-root", type=Path, default=Path.home() / ".qwen")
    args = parser.parse_args()
    dist = Path(__file__).parent / "dist"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_root = Path.home() / ".t4h-agent-os" / "legacy-backups" / stamp
    candidates: list[tuple[Path, Path]] = []
    for folder in ("agents", "arenas", "playbooks"):
        for managed in sorted((dist / folder).glob("*.md")):
            legacy = args.legacy_root / folder / managed.name
            if legacy.is_file():
                candidates.append((legacy, backup_root / folder / managed.name))
    if args.apply:
        for source, backup in candidates:
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, backup)
            source.unlink()
    print(json.dumps({
        "status": "REAL" if args.apply else "PARTIAL",
        "mode": "apply" if args.apply else "dry-run",
        "legacy_root": str(args.legacy_root),
        "matched_managed_files": len(candidates),
        "backed_up_and_removed": len(candidates) if args.apply else 0,
        "backup_root": str(backup_root) if args.apply else None,
        "unmanaged_files_untouched": True,
    }, indent=2))


if __name__ == "__main__":
    main()
